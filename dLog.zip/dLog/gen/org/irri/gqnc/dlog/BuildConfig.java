/** Automatically generated file. DO NOT MODIFY */
package org.irri.gqnc.dlog;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}